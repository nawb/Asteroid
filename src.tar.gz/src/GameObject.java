import java.awt.*;
import java.lang.*;
import java.math.*;
public class GameObject {
	double x_vel;
	double y_vel;
	int name;
	int radius;
	boolean active;
	
	Point pos = new Point();

	public GameObject()
	{
		//this.x_vel = x_vel;
		//this.y_vel = y_vel;
	}

}
